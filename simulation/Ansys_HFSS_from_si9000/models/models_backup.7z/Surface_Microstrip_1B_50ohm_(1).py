# -----------------------------------------------------------------------------------
#  [Ansys ver]Ansys Electronics Desktop Version 2024.2.0
#  [Date]  Aug 8, 2025
#  [File name] Surface_Microstrip_1B_50ohm_(1)
#  [Notes]  The impedance is a single-ended microstrip line of 50 ohm.
#  [Author's Email]  3405802009@qq.com
# -----------------------------------------------------------------------------------
import os
import win32com.client
import pandas as pd
import camelot.io as  camelot
import ansys.aedt.core
##########################################Mkdir############################################################
if not os.path.exists("../HFSS_Projects"):
    os.mkdir("../HFSS_Projects")
if not os.path.exists("../sim_results"):
    os.mkdir("../sim_results")
##################################Read input_files from si 9000 ###########################################
tables=camelot.read_pdf('../input_files/Surface_Microstrip_1B_50ohm_(1).pdf' , pages=('1'), flavor='stream')
tables.export('../input_files/Surface_Microstrip_1B_50ohm_(1).csv',f='csv')

excel_file_path="../input_files/Surface_Microstrip_1B_50ohm_(1)-page-1-table-1.csv"
sheet_name="Surface_Microstrip_1B_50ohm_(1)"
# Read excel.
df = pd.read_csv(excel_file_path, sep=',' , header=0, encoding='gb18030')
print(df)
#value=df.iloc[:,:3]
#print(value)
############################################################################################################
oAnsoftApp = win32com.client.Dispatch('AnsoftHfss.HfssScriptInterface')
oDesktop = oAnsoftApp.GetAppDesktop()
oDesktop.RestoreWindow()
## oProject = oDesktop.GetActiveProject()
## path = os.getcwd()#获取当前py文件所在文件夹
## filename = 'IFA1.hfss'
## fullname = os.path.join(path, filename)
## oDesktop.OpenProject(fullname)
## oDesktop.OpenProject("..\\HFSS_Projects\\Surface_Microstrip_1B_50ohm_(1).aedt")
## oProject = oDesktop.SetActiveProject("Surface_Microstrip_1B_50ohm_(1)")
oProject = oDesktop.NewProject()
oProject.InsertDesign("HFSS", "Surface_Microstrip_1B_50ohm_(1)", "DrivenTerminal", "")
oDesign = oProject.SetActiveDesign("Surface_Microstrip_1B_50ohm_(1)")
oProject.SaveAs("C:\\00_Asenjo\\00_Project\\Ketupa\\simulation\\Ansys_HFSS_from_si9000\\HFSS_Projects\\Surface_Microstrip_1B_50ohm_(1).aedt", True)
###############################################################################################################
# Define constants.
AEDT_VERSION = "2024.2"
NUM_CORES = 4
# Create a temporary directory where downloaded data or dumped data can be stored.
# If you’d like to retrieve the project data for subsequent use, the temporary folder name is given by .temp_folder.name.

Hfss = ansys.aedt.core.Hfss("C:\\00_Asenjo\\00_Project\\Ketupa\\simulation\\Ansys_HFSS_from_si9000\\HFSS_Projects\\Surface_Microstrip_1B_50ohm_(1).aedt")
# Define variables.

core_h = "H1"
e_factor = "$Er1"
Lower_Trace_Width = "W1"
Upper_Trace_Width = "W2"
cond_h = "T1"

value1=df.iloc[0,2]
value2=df.iloc[1,2]
value3=df.iloc[2,2]
value4=df.iloc[3,2]
value5=df.iloc[4,2]

for var_name, var_value in {
    "H1": f"{value1:.2f}" + "um",
    "$Er1":f"{value2:.2f}",
    "W1": f"{value3:.2f}" + "um",
    "W2": f"{value4:.2f}" + "um",
    "T1": f"{value5:.2f}" + "um",
	"subX": "5" "mm",
    "subY": "10" "mm",
    "subH": f"{float(value1) / 1000:.4f}" + "mm",
}.items():
    Hfss[var_name] = var_value

# 创建基元
# 创建基元并定义层高度

layer_1_lh = 0
layer_1_uh = cond_h
layer_2_lh = layer_1_uh + "+" + core_h
layer_2_uh = layer_2_lh + "+" + cond_h

Hfss.save_project(r"C:\\00_Asenjo\\00_Project\\Ketupa\\simulation\\Ansys_HFSS_from_si9000\\HFSS_Projects\\Surface_Microstrip_1B_50ohm_(1).aedt", overwrite=True)
Hfss.release_desktop(close_projects=True)
############################################################################################################
oAnsoftApp = win32com.client.Dispatch('AnsoftHfss.HfssScriptInterface')
oDesktop = oAnsoftApp.GetAppDesktop()
oDesktop.RestoreWindow()
oDesktop.OpenProject("C:\\00_Asenjo\\00_Project\\Ketupa\\simulation\\Ansys_HFSS_from_si9000\\HFSS_Projects\\Surface_Microstrip_1B_50ohm_(1).aedt")
oProject = oDesktop.SetActiveProject("Surface_Microstrip_1B_50ohm_(1)")
oDesign = oProject.SetActiveDesign("Surface_Microstrip_1B_50ohm_(1)")
########################Create 3D Modeler ##############################
oEditor = oDesign.SetActiveEditor("3D Modeler")
oEditor.CreateBox(
	[
		"NAME:BoxParameters",
		"XPosition:="		, "0mm",
		"YPosition:="		, "0mm",
		"ZPosition:="		, "0mm",
		"XSize:="		, "subX",
		"YSize:="		, "subY",
		"ZSize:="		, "H1"
	],
	[
		"NAME:Attributes",
		"Name:="		, "Dielectric1",
		"Flags:="		, "",
		"Color:="		, "(143 175 143)",
		"Transparency:="	, 0,
		"PartCoordinateSystem:=", "Global",
		"UDMId:="		, "",
		"MaterialValue:="	, "\"vacuum\"",
		"SurfaceMaterialValue:=", "\"\"",
		"SolveInside:="		, True,
		"ShellElement:="	, False,
		"ShellElementThickness:=", "0mm",
		"ReferenceTemperature:=", "20cel",
		"IsMaterialEditable:="	, True,
		"IsSurfaceMaterialEditable:=", True,
		"UseMaterialAppearance:=", False,
		"IsLightweight:="	, False
	])
oDefinitionManager = oProject.GetDefinitionManager()
oDefinitionManager.AddMaterial(
	[
		"NAME:Substrate 1 Dielectric",
		"CoordinateSystemType:=", "Cartesian",
		"BulkOrSurfaceType:="	, 1,
		[
			"NAME:PhysicsTypes",
			"set:="			, ["Electromagnetic"]
		],
		"permittivity:="	, "$Er1",
		"permeability:="	, "1.00001",
		"dielectric_loss_tangent:=", "0.085"
	])

oEditor.AssignMaterial(
	[
		"NAME:Selections",
		"AllowRegionDependentPartSelectionForPMLCreation:=", True,
		"AllowRegionSelectionForPMLCreation:=", True,
		"Selections:="		, "Dielectric1"
	],
	[
		"NAME:Attributes",
		"MaterialValue:="	, "\"Substrate 1 Dielectric\"",
		"SolveInside:="		, True,
		"ShellElement:="	, False,
		"ShellElementThickness:=", "nan ",
		"ReferenceTemperature:=", "nan ",
		"IsMaterialEditable:="	, True,
		"IsSurfaceMaterialEditable:=", True,
		"UseMaterialAppearance:=", False,
		"IsLightweight:="	, False
	])

oEditor = oDesign.SetActiveEditor("3D Modeler")
oEditor.CreateBox(
	[
		"NAME:BoxParameters",
		"XPosition:="		, "0mm",
		"YPosition:="		, "0mm",
		"ZPosition:="		, "0mm",
		"XSize:="		, "subX",
		"YSize:="		, "subY",
		"ZSize:="		, "-T1"
	],
	[
		"NAME:Attributes",
		"Name:="		, "Gnd",
		"Flags:="		, "",
		"Color:="		, "(253 187 66)",
		"Transparency:="	, 0,
		"PartCoordinateSystem:=", "Global",
		"UDMId:="		, "",
		"MaterialValue:="	, "\"copper\"",
		"SurfaceMaterialValue:=", "\"\"",
		"SolveInside:="		, True,
		"ShellElement:="	, False,
		"ShellElementThickness:=", "0mm",
		"ReferenceTemperature:=", "20cel",
		"IsMaterialEditable:="	, True,
		"IsSurfaceMaterialEditable:=", True,
		"UseMaterialAppearance:=", False,
		"IsLightweight:="	, False
	])

oEditor = oDesign.SetActiveEditor("3D Modeler")
oEditor.CreatePolyline(
	[
		"NAME:PolylineParameters",
		"IsPolylineCovered:="	, True,
		"IsPolylineClosed:="	, True,
		[
			"NAME:PolylinePoints",
			[
				"NAME:PLPoint",
				"X:="			, "(subX/2)-(W1)/2",
				"Y:="			, "0mm",
				"Z:="			, "H1"
			],
			[
				"NAME:PLPoint",
				"X:="			, "(subX/2)+(W1)/2",
				"Y:="			, "0mm",
				"Z:="			, "H1"
			],
			[
				"NAME:PLPoint",
				"X:="			, "(subX/2)+(W2)/2",
				"Y:="			, "0mm",
				"Z:="			, "H1+T1"
			],
			[
				"NAME:PLPoint",
				"X:="			, "(subX/2)-(W2)/2",
				"Y:="			, "0mm",
				"Z:="			, "H1+T1"
			],
			[
				"NAME:PLPoint",
				"X:="			, "(subX/2)-(W1)/2",
				"Y:="			, "0mm",
				"Z:="			, "H1"
			]
		],
		[
			"NAME:PolylineSegments",
			[
				"NAME:PLSegment",
				"SegmentType:="		, "Line",
				"StartIndex:="		, 0,
				"NoOfPoints:="		, 2
			],
			[
				"NAME:PLSegment",
				"SegmentType:="		, "Line",
				"StartIndex:="		, 1,
				"NoOfPoints:="		, 2
			],
			[
				"NAME:PLSegment",
				"SegmentType:="		, "Line",
				"StartIndex:="		, 2,
				"NoOfPoints:="		, 2
			],
			[
				"NAME:PLSegment",
				"SegmentType:="		, "Line",
				"StartIndex:="		, 3,
				"NoOfPoints:="		, 2
			]
		],
		[
			"NAME:PolylineXSection",
			"XSectionType:="	, "None",
			"XSectionOrient:="	, "Auto",
			"XSectionWidth:="	, "0mm",
			"XSectionTopWidth:="	, "0mm",
			"XSectionHeight:="	, "0mm",
			"XSectionNumSegments:="	, "0",
			"XSectionBendType:="	, "Corner"
		]
	],
	[
		"NAME:Attributes",
		"Name:="		, "Microstrip_1B",
		"Flags:="		, "",
		"Color:="		, "(253 187 66)",
		"Transparency:="	, 0,
		"PartCoordinateSystem:=", "Global",
		"UDMId:="		, "",
		"MaterialValue:="	, "\"copper\"",
		"SurfaceMaterialValue:=", "\"\"",
		"SolveInside:="		, True,
		"ShellElement:="	, False,
		"ShellElementThickness:=", "0mm",
		"ReferenceTemperature:=", "20cel",
		"IsMaterialEditable:="	, True,
		"IsSurfaceMaterialEditable:=", True,
		"UseMaterialAppearance:=", False,
		"IsLightweight:="	, False
	])
oEditor.ThickenSheet(
	[
		"NAME:Selections",
		"Selections:="		, "Microstrip_1B",
		"NewPartsModelFlag:="	, "Model"
	],
	[
		"NAME:SheetThickenParameters",
		"Thickness:="		, "-subY",
		"BothSides:="		, False,
		[
			"NAME:ThickenAdditionalInfo",
			[
				"NAME:ShellThickenDirectionInfo",
				"SampleFaceID:="	, 98,
				"ComponentSense:="	, True,
				[
					"NAME:PointOnSampleFace",
					"X:="			, "25.1397887mm",
					"Y:="			, "0mm",
					"Z:="			, "1.01279281mm"
				],
				[
					"NAME:DirectionAtPoint",
					"X:="			, "0mm",
					"Y:="			, "-1mm",
					"Z:="			, "0mm"
				]
			]
		]
	])

oEditor.CreateBox(
	[
		"NAME:BoxParameters",
		"XPosition:="		, "0",
		"YPosition:="		, "0",
		"ZPosition:="		, "-T1",
		"XSize:="		, "subX",
		"YSize:="		, "subY",
		"ZSize:="		, "10*subH+T1"
	],
	[
		"NAME:Attributes",
		"Name:="		, "AirBox",
		"Flags:="		, "",
		"Color:="		, "(143 175 143)",
		"Transparency:="	, 0.95,
		"PartCoordinateSystem:=", "Global",
		"UDMId:="		, "",
		"MaterialValue:="	, "\"air\"",
		"SurfaceMaterialValue:=", "\"\"",
		"SolveInside:="		, True,
		"ShellElement:="	, False,
		"ShellElementThickness:=", "0mm",
		"ReferenceTemperature:=", "20cel",
		"IsMaterialEditable:="	, True,
		"IsSurfaceMaterialEditable:=", True,
		"UseMaterialAppearance:=", False,
		"IsLightweight:="	, False
	])
##############################Add port###############################
oEditor = oDesign.SetActiveEditor("3D Modeler")
oEditor.CreateRectangle(
	[
		"NAME:RectangleParameters",
		"IsCovered:="		, True,
		"XStart:="		, "(subX)/2",
		"YStart:="		, "0",
		"ZStart:="		, "10*subH",
		"Width:="		, "-10*subH-T1",
		"Height:="		, "-6*W1",
		"WhichAxis:="		, "Y"
	],
	[
		"NAME:Attributes",
		"Name:="		, "port1",
		"Flags:="		, "",
		"Color:="		, "(143 175 143)",
		"Transparency:="	, 0.8,
		"PartCoordinateSystem:=", "Global",
		"UDMId:="		, "",
		"MaterialValue:="	, "\"vacuum\"",
		"SurfaceMaterialValue:=", "\"\"",
		"SolveInside:="		, True,
		"ShellElement:="	, False,
		"ShellElementThickness:=", "0mm",
		"ReferenceTemperature:=", "20cel",
		"IsMaterialEditable:="	, True,
		"IsSurfaceMaterialEditable:=", True,
		"UseMaterialAppearance:=", False,
		"IsLightweight:="	, False
	])
oEditor.CreateRectangle(
	[
		"NAME:RectangleParameters",
		"IsCovered:="		, True,
		"XStart:="		, "(subX)/2",
		"YStart:="		, "0",
		"ZStart:="		, "10*subH",
		"Width:="		, "-10*subH-T1",
		"Height:="		, "6*W1",
		"WhichAxis:="		, "Y"
	],
	[
		"NAME:Attributes",
		"Name:="		, "port2",
		"Flags:="		, "",
		"Color:="		, "(143 175 143)",
		"Transparency:="	, 0.8,
		"PartCoordinateSystem:=", "Global",
		"UDMId:="		, "",
		"MaterialValue:="	, "\"vacuum\"",
		"SurfaceMaterialValue:=", "\"\"",
		"SolveInside:="		, True,
		"ShellElement:="	, False,
		"ShellElementThickness:=", "0mm",
		"ReferenceTemperature:=", "20cel",
		"IsMaterialEditable:="	, True,
		"IsSurfaceMaterialEditable:=", True,
		"UseMaterialAppearance:=", False,
		"IsLightweight:="	, False
	])
oEditor.Unite(
	[
		"NAME:Selections",
		"Selections:="		, "port1,port2"
	],
	[
		"NAME:UniteParameters",
		"KeepOriginals:="	, False,
		"TurnOnNBodyBoolean:="	, True
	])

oEditor.CreateRectangle(
	[
		"NAME:RectangleParameters",
		"IsCovered:="		, True,
		"XStart:="		, "(subX)/2",
		"YStart:="		, "subY",
		"ZStart:="		, "10*subH",
		"Width:="		, "-10*subH-T1",
		"Height:="		, "-6*W1",
		"WhichAxis:="		, "Y"
	],
	[
		"NAME:Attributes",
		"Name:="		, "port3",
		"Flags:="		, "",
		"Color:="		, "(143 175 143)",
		"Transparency:="	, 0.5,
		"PartCoordinateSystem:=", "Global",
		"UDMId:="		, "",
		"MaterialValue:="	, "\"vacuum\"",
		"SurfaceMaterialValue:=", "\"\"",
		"SolveInside:="		, True,
		"ShellElement:="	, False,
		"ShellElementThickness:=", "0mm",
		"ReferenceTemperature:=", "20cel",
		"IsMaterialEditable:="	, True,
		"IsSurfaceMaterialEditable:=", True,
		"UseMaterialAppearance:=", False,
		"IsLightweight:="	, False
	])
oEditor.CreateRectangle(
	[
		"NAME:RectangleParameters",
		"IsCovered:="		, True,
		"XStart:="		, "(subX)/2",
		"YStart:="		, "subY",
		"ZStart:="		, "10*subH",
		"Width:="		, "-10*subH-T1",
		"Height:="		, "6*W1",
		"WhichAxis:="		, "Y"
	],
	[
		"NAME:Attributes",
		"Name:="		, "port4",
		"Flags:="		, "",
		"Color:="		, "(143 175 143)",
		"Transparency:="	, 0.5,
		"PartCoordinateSystem:=", "Global",
		"UDMId:="		, "",
		"MaterialValue:="	, "\"vacuum\"",
		"SurfaceMaterialValue:=", "\"\"",
		"SolveInside:="		, True,
		"ShellElement:="	, False,
		"ShellElementThickness:=", "0mm",
		"ReferenceTemperature:=", "20cel",
		"IsMaterialEditable:="	, True,
		"IsSurfaceMaterialEditable:=", True,
		"UseMaterialAppearance:=", False,
		"IsLightweight:="	, False
	])
oEditor.Unite(
	[
		"NAME:Selections",
		"Selections:="		, "port3,port4"
	],
	[
		"NAME:UniteParameters",
		"KeepOriginals:="	, False,
		"TurnOnNBodyBoolean:="	, True
	])
#########################Add Radiation#####################################
oModule = oDesign.GetModule("BoundarySetup")
oModule.AssignRadiation(
	[
		"NAME:Rad1",
		"Objects:="		, ["AirBox"]
	])
oModule.AutoIdentifyPorts(
	[
		"NAME:Faces",
		139
	], True,
	[
		"NAME:ReferenceConductors",
		"Gnd"
	], "1", True)
oModule.AutoIdentifyPorts(
	[
		"NAME:Faces",
		164
	], True,
	[
		"NAME:ReferenceConductors",
		"Gnd"
	], "2", True)
############################Analysis#######################################
oModule = oDesign.GetModule("AnalysisSetup")
oModule.InsertSetup("HfssDriven",
	[
		"NAME:Setup1",
		"SolveType:="		, "Single",
		"Frequency:="		, "4GHz",
		"MaxDeltaS:="		, 0.02,
		"UseMatrixConv:="	, False,
		"MaximumPasses:="	, 6,
		"MinimumPasses:="	, 1,
		"MinimumConvergedPasses:=", 1,
		"PercentRefinement:="	, 30,
		"IsEnabled:="		, True,
		[
			"NAME:MeshLink",
			"ImportMesh:="		, False
		],
		"BasisOrder:="		, 1,
		"DoLambdaRefine:="	, True,
		"DoMaterialLambda:="	, True,
		"SetLambdaTarget:="	, False,
		"Target:="		, 0.3333,
		"UseMaxTetIncrease:="	, False,
		"PortAccuracy:="	, 2,
		"UseABCOnPort:="	, False,
		"SetPortMinMaxTri:="	, False,
		"DrivenSolverType:="	, "Direct Solver",
		"EnhancedLowFreqAccuracy:=", False,
		"SaveRadFieldsOnly:="	, False,
		"SaveAnyFields:="	, True,
		"IESolverType:="	, "Auto",
		"LambdaTargetForIESolver:=", 0.15,
		"UseDefaultLambdaTgtForIESolver:=", True,
		"IE Solver Accuracy:="	, "Balanced",
		"InfiniteSphereSetup:="	, "",
		"MaxPass:="		, 10,
		"MinPass:="		, 1,
		"MinConvPass:="		, 1,
		"PerError:="		, 1,
		"PerRefine:="		, 30
	])
oModule.InsertFrequencySweep("Setup1",
	[
		"NAME:Sweep",
		"IsEnabled:="		, True,
		"RangeType:="		, "LinearCount",
		"RangeStart:="		, "0Hz",
		"RangeEnd:="		, "1Hz",
		"RangeCount:="		, 1,
		[
			"NAME:SweepRanges",
			[
				"NAME:Subrange",
				"RangeType:="		, "LogScale",
				"RangeStart:="		, "1Hz",
				"RangeEnd:="		, "100MHz",
				"RangeCount:="		, 401,
				"RangeSamples:="	, 20
			],
			[
				"NAME:Subrange",
				"RangeType:="		, "LinearStep",
				"RangeStart:="		, "100MHz",
				"RangeEnd:="		, "1GHz",
				"RangeStep:="		, "10MHz"
			],
			[
				"NAME:Subrange",
				"RangeType:="		, "LinearStep",
				"RangeStart:="		, "1GHz",
				"RangeEnd:="		, "16GHz",
				"RangeStep:="		, "10MHz"
			]
		],
		"Type:="		, "Interpolating",
		"SaveFields:="		, True,
		"SaveRadFields:="	, True,
		"InterpTolerance:="	, 0.5,
		"InterpMaxSolns:="	, 250,
		"InterpMinSolns:="	, 0,
		"InterpMinSubranges:="	, 1,
		"MinSolvedFreq:="	, "0.01GHz",
		"InterpUseS:="		, True,
		"InterpUsePortImped:="	, True,
		"InterpUsePropConst:="	, True,
		"UseDerivativeConvergence:=", False,
		"InterpDerivTolerance:=", 0.2,
		"UseFullBasis:="	, True,
		"EnforcePassivity:="	, True,
		"PassivityErrorTolerance:=", 0.0001,
		"EnforceCausality:="	, False
	])
##################################Save and Analyze##############################
oProject.SaveAs("C:\\00_Asenjo\\00_Project\\Ketupa\\simulation\\Ansys_HFSS_from_si9000\\HFSS_Projects\\Surface_Microstrip_1B_50ohm_(1).aedt", True)
oDesign.AnalyzeAll()
##################################Create Reports################################
oModule = oDesign.GetModule("ReportSetup")
oModule.CreateReport("Terminal S Parameter Plot 1", "Terminal Solution Data", "Rectangular Plot", "Setup1 : Sweep",
	[
		"Domain:="		, "Sweep"
	],
	[
		"Freq:="		, ["All"],
		"H1:="			, ["Nominal"],
		"W1:="			, ["Nominal"],
		"W2:="			, ["Nominal"],
		"T1:="			, ["Nominal"],
		"subX:="		, ["Nominal"],
		"subY:="		, ["Nominal"],
		"subH:="		, ["Nominal"],
		"$Er1:="		, ["Nominal"]
	],
	[
		"X Component:="		, "Freq",
		"Y Component:="		, ["dB(St(Microstrip_1B_T1,Microstrip_1B_T1))","dB(St(Microstrip_1B_T2,Microstrip_1B_T1))"]
	])
oModule.CreateReport("Terminal TDR Impedance Plot 2", "Terminal Solution Data", "Rectangular Plot", "Setup1 : Sweep",
	[
		"Domain:="		, "Time",
		"HoldTime:="		, 1,
		"RiseTime:="		, 2E-10,
		"StepTime:="		, 4E-11,
		"Step:="		, True,
		"WindowWidth:="		, 1,
		"WindowType:="		, 4,
		"KaiserParameter:="	, 1,
		"MaximumTime:="		, 4E-09
	],
	[
		"Time:="		, ["All"],
		"H1:="			, ["Nominal"],
		"W1:="			, ["Nominal"],
		"W2:="			, ["Nominal"],
		"T1:="			, ["Nominal"],
		"subX:="		, ["Nominal"],
		"subY:="		, ["Nominal"],
		"subH:="		, ["Nominal"],
		"$Er1:="		, ["Nominal"]
	],
	[
		"X Component:="		, "Time",
		"Y Component:="		, ["TDRZt(Microstrip_1B_T1)"]
	])
##################################Save Reports###########################################
oModule = oDesign.GetModule("ReportSetup")
oModule.ExportToFile("Terminal S Parameter Plot 1", "C:\\00_Asenjo\\00_Project\\Ketupa\\simulation\\Ansys_HFSS_from_si9000\\sim_results\\Surface_Microstrip_1B_50ohm_(1).csv", False)
oModule.ExportImageToFile("Terminal S Parameter Plot 1", "C:\\00_Asenjo\\00_Project\\Ketupa\\simulation\\Ansys_HFSS_from_si9000\\sim_results\\Surface_Microstrip_1B_50ohm_(1).bmp", 2030, 1102)
##################################Save s para############################################
oModule = oDesign.GetModule("Solutions")
oModule.ExportNetworkData("D=\'10um\' L=\'100um\' Lg=\'20um\' W=\'6um\'", ["Setup1:Sweep"], 3, "C:\\00_Asenjo\\00_Project\\Ketupa\\simulation\\Ansys_HFSS_from_si9000\\sim_results\Surface_Microstrip_1B_50ohm_(1).s4p",
						  ["All"], True, 50, "S", -1, 0, 15, True, True, False)
#######################################Save #############################################
oProject.SaveAs("C:\\00_Asenjo\\00_Project\\Ketupa\\simulation\\Ansys_HFSS_from_si9000\\HFSS_Projects\\Surface_Microstrip_1B_50ohm_(1).aedt", True)